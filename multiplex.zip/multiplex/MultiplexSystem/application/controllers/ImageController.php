<?php
    class ImageController extends CI_Controller{
        public function index(){
            
        }
    }
?>